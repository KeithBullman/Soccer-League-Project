// Name: Keith Bullman
// ID: R00178736
// Class: SDH2-A

package junit;

import model.Player;

public class playerTest {

	public void Run() {
		
		Player testPlayer = new Player("Keith", "Edward", "Bullman", "12345678", "keith.bullman@mycit.ie", 5, true);
		
		int answer = testPlayer.getGoals();
		
		Compare(5, answer);
		
	}
	
	private void Compare(int actualAmount, int testAmount) {
		
		if(actualAmount == testAmount) {
			System.out.println("Test Successful");
		}
		
		else {
			System.out.println("Test Failed");
		}
		
	}
	
}
