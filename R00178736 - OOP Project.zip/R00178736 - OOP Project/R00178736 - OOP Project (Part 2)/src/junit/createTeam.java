// Name: Keith Bullman
// ID: R00178736
// Class: SDH2-A

package junit;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import model.Team;

class createTeam {

	@Test
	void test() {
		
		Team junit = new Team("Meath", "Green");
		
		String answer = junit.getColour();

		assertEquals("Red", answer);
		
	}

}
