// Name: Keith Bullman
// ID: R00178736
// Class: SDH2-A

package junit;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import model.Manager;

class createManager {

	@Test
	void test() {
		
		Manager junit = new Manager("Test", "John", "Edwards", "12345678", "keith.bullman@mycit.ie", "01-01-1900", 5);
		
		int answer = junit.getStar();

		assertEquals(5, answer);
		
	}

}
