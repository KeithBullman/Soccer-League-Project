// Name: Keith Bullman
// ID: R00178736
// Class: SDH2-A

package controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import model.Player;
import model.Manager;
import model.Team;

@SuppressWarnings("unused")
public class dbquery {

	//INSERT PLAYER QUERY
	public static String insertPlayer(Connection con, model.Name name, model.Player player) {
		
		try {
			
			String isGoalie = "";
			
			if(player.getGoalie() == true) {
				isGoalie = "y";
			}
			else {
				isGoalie = "n";
			}
			
			String query = "INSERT INTO player VALUES ('" + name.getFirst() + "', '" + name.getMiddle() + "', '" + name.getLast() + "', '" + player.getGoals() + "', '" + isGoalie + "')";
			
			PreparedStatement prepared = con.prepareStatement(query);
			
			prepared.execute();
			
			prepared.close();
			
			return "Player Created";
			
		} catch(Exception e) {
			return "Error!";
		}
		
	}
	
	
	
	//INSERT MANAGER QUERY
	public static String insertManager(Connection con, model.Name name, model.Manager manager) {
		
		try {
			
			String query = "INSERT INTO manager VALUES ('" + name.getFirst() + "', '" + name.getMiddle() + "', '" + name.getLast() + "', '" + manager.getDOB() + "', '" + manager.getStar() + "')";
			
			PreparedStatement prepared = con.prepareStatement(query);
			
			prepared.execute();
			
			prepared.close();
			
			return "Manager Created";
			
		} catch(Exception e) {
			return "Error!";
		}
		
	}
	
	
	
	//INSERT TEAM QUERY
	public static String insertTeam(Connection con, model.Team team) {
		
		try {
			
			String query = "INSERT INTO team VALUES ('" + team.getName() + "', '" + team.getColour() + "')";
			
			PreparedStatement prepared = con.prepareStatement(query);
			
			prepared.execute();
			
			prepared.close();
			
			return "Team Created";
			
		} catch(Exception e) {
			return "Error!";
		}
	}

	
	
	//ADD PLAYER TO TEAM
	public static String addTeamPlayer(Connection con, String playerName, String teamName) {
		
		try {
			
			String query = "INSERT INTO teamPlayers VALUES ('" + teamName + "', '" + playerName + "')";
			
			PreparedStatement prepared = con.prepareStatement(query);
			
			prepared.execute();
			
			prepared.close();
			
			return "Player Added to Team";
			
		} catch(Exception e) {
			return "Error!";
		}
	}
	
	
	
	//ADD MANAGER TO TEAM
	public static String addTeamManager(Connection con, String managerName, String teamName) {
		
		try {
				
			String query = "INSERT INTO teamManagers VALUES ('" + managerName + "', '" + teamName + "')";
		
			PreparedStatement prepared = con.prepareStatement(query);
			
			prepared.execute();
			
			prepared.close();
			
			return "Manager Added to Team";
		
		} catch(Exception e) {
			return "Error!";
		}
	}
	
	
	
	//EDIT PLAYER GOAL COUNT
	public static String editPlayer(Connection con, String fName, String lName, String goals) {
		
		try {
			
			String query = "UPDATE player SET goals = '" + goals + "' WHERE fName = '" + fName + "' AND lName = '" + lName + "'";
			
			PreparedStatement prepared = con.prepareStatement(query);
			
			prepared.execute();
			
			prepared.close();
			
			return "Player Goals Updated";
			
		}catch(Exception e) {
			return "Error!";
		}
	}
	
	
	
	//REMOVE PLAYER
	public static String removePlayer(Connection con, String fname, String lname) {
		
		try {
			
			String query = "DELETE FROM player WHERE fname = '" + fname + "' AND lname = '" + lname + "'";
			
			PreparedStatement prepared = con.prepareStatement(query);
			
			prepared.executeUpdate();
			
			prepared.close();
			
			return "Player Removed";
			
		} catch(Exception e) {
			return "Error!";
		}
	}
	
	
	
	//REMOVE MANAGER
	public static String removeManager(Connection con, String fname, String lname) {
		
		try {
			
			String query = "DELETE FROM manager WHERE fname = '" + fname + "' AND lname = '" + lname + "'";
			
			PreparedStatement prepared = con.prepareStatement(query);
			
			prepared.executeUpdate();
			
			prepared.close();
			
			return "Manager Removed";
			
		} catch(Exception e) {
			return "Error!";
		}
	}
	
	
	
	//REMOVE TEAM
	public static String removeTeam(Connection con, String name) {
		
		try {
			
			String query = "DELETE FROM team WHERE name = '" + name + "'";
			
			PreparedStatement prepared = con.prepareStatement(query);
			
			prepared.executeUpdate();
			
			prepared.close();
			
			return "Team Removed";
			
		} catch(Exception e) {
			return "Error!";
		}
	}
	
	
	
	//LIST MANAGERS QUERY
	public static String listManagers(Connection con) {
		
		try {
			
			String answer = "";
			
			Statement query = con.createStatement();
			
			String search = "SELECT fname, lname, star FROM manager";
			
			ResultSet result = query.executeQuery(search);
			
			while(result.next()) {
				answer += result.getString(1);
				answer += result.getString(2) + " Rating: ";
				answer += result.getString(3) + "\n=====\n";
			}
			
			if(answer == "") {
				return "No entries found!";
			}
			else {
				return answer;
			}
			
			
		} catch(Exception e) {
			return "Error!";
		}
	}
	
	
	
	//LIST TEAMS QUERY
	public static String listTeams(Connection con) {
		
		try {
			
			String answer = "";
			
			Statement query = con.createStatement();
			
			String search = "SELECT name FROM team";
			
			ResultSet result = query.executeQuery(search);
			
			while(result.next()) {
				answer += result.getString(1) + "\n=====";
			}
			
			if(answer == "") {
				return "No entries found!";
			}
			else {
				return answer;
			}
			
			
		} catch(Exception e) {
			return "Error!";
		}
	}
	
	
	
	//LIST PLAYERS IN TEAM
	public static String listTeamPlayers(Connection con, String teamName) {
		
		try {
			
			String answer = "";
			
			Statement query = con.createStatement();
			
			/**
			 * If there is no teamName inputted by user; just return every player name that is on any team
			 */
			
			if(teamName == "") {
				
				String search = "SELECT playerName from teamPlayers";
				
				ResultSet result = query.executeQuery(search);
				
				while(result.next()) {
					answer += result.getString(1) + "\n=====\n";
				}
				
				if(answer == "") {
					return "No players found";
				}
				
				else {
					return answer;
				}
				
			}
			
			/**
			 * Otherwise, return the name of each player that is on the teamName specified by the user
			 */
			
			else {
				
				String search = "SELECT playerName FROM teamPlayers WHERE teamName = '" + teamName + "'";
				
				ResultSet result = query.executeQuery(search);
				
				while(result.next()) {
					answer += result.getString(1) + "\n=====\n";
				}
				
				if(answer == "") {
					return "No players on team";
				}
				
				else {
					return answer;
				}
			
			}
		} catch(Exception e) {
			return "Error!";
		}
	}
}
