// Name: Keith Bullman
// ID: R00178736
// Class: SDH2-A

package controller;

import java.sql.Connection;

public class league {

	public static Connection createConnection() {
		return model.ConnectSQL.create();
	}
	
}
