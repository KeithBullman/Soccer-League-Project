// Name: Keith Bullman
// ID: R00178736
// Class: SDH2-A

package model;

import java.util.ArrayList;

public class League {

	private ArrayList<Team> teams;
	private String name;
	
	public League(String name) {
		this.teams = new ArrayList<Team>();
		this.name = name;
	}
	
	public String getTeams() {
		String result = "";
		for (int counter = 0; counter < teams.size(); counter++) {
			if(counter+1 == teams.size()) {
				result += teams.get(counter).getName();
			}
			else {
				result += teams.get(counter).getName() + ", ";
			}
		}
		return result;
	}
	
	public String getName() {
		return this.name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public void addTeam(Team team) {
		this.teams.add(team);
	}
	
	public void removeTeam(int pointer) {
		this.teams.remove(pointer);
	}
}
