// Name: Keith Bullman
// ID: R00178736
// Class: SDH2-A

package model;

public class Person {

	private Name name;
	private String phone;
	private String email;
	
	public Person(String first, String middle, String last, String ph, String em) {
		
		this.name = new Name(first, middle, last);
		this.phone = ph;
		this.email = em;
		
	}
	
	public Name getName() {
		return this.name;
	}
	
	public void setName(Name n) {
		this.name = n;
	}
	
	public String getPhone() {
		return this.phone;
	}
	
	public void setPhone(String ph) {
		this.phone = ph;
	}
	
	public String getEmail() {
		return this.email;
	}
	
	public void setEmail(String em) {
		this.email = em;
	}
}
