// Name: Keith Bullman
// ID: R00178736
// Class: SDH2-A

package model;

import java.sql.Connection;
import java.sql.DriverManager;

public class ConnectSQL {

	public static Connection create() {
		
		try {
			
			String name = "mysql-connector-java-8.0.20";
			
			Class.forName(name);
			
			//Connect with user name 'root' and password 'root'
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/databaseproject", "root", "password");
			
			System.out.println("Connection Complete");
			
			return con;
			
		} catch(Exception e) {
			
			System.out.println("Failed to Connect to Database!");
			return null;
			
		}
	}
}
