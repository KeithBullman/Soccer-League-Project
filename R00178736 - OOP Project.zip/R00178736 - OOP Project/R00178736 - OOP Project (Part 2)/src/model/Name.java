// Name: Keith Bullman
// ID: R00178736
// Class: SDH2-A

package model;

public class Name {
	
	private String firstName;
	private String middleName;
	private String lastName;
	
	public Name(String fName, String mName, String lName) {
		this.firstName = fName;
		this.middleName = mName;
		this.lastName = lName;
	}
	
	public String getFirst() {
		return this.firstName;
	}
	
	public void setFirst(String first) {
		this.firstName = first;
	}
	
	public String getMiddle() {
		return this.middleName;
	}
	
	public void setMiddle(String middle) {
		this.middleName = middle;
	}
	
	public String getLast() {
		return this.lastName;
	}
	
	public void setLast (String last) {
		this.lastName = last;
	}
	
	public String toString() {
		String res = firstName + "";
		
		if(middleName != "") {
			res += middleName + "";
		}
		
		res += lastName;
		return res;
	}
}
