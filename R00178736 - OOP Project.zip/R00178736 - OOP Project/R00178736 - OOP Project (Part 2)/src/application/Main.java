// Name: Keith Bullman
// ID: R00178736
// Class: SDH2-A

package application;

import java.sql.Connection;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

public class Main extends Application {
	
	Button home, exit, add, addPlayer, remove, removePlayer, edit, addManager, removeManager, addTeam, removeTeam, addTeamPlayer, removeTeamPlayer, addTeamManager, removeTeamManager, removeHome, editHome, editPlayer, listTeams, listManagers, listTeamPlayers;
	Scene homeScene, addScene, removeScene, editScene;
	
	@Override
	public void start(Stage primaryStage) {
		
		Connection con = controller.league.createConnection();
		
		Stage window = primaryStage;
		
		/**
		 * Create headers for 'adding players, managers, team' scene
		 */
		
		Label playerHeader = new Label("~ PLAYERS ~");
		
		Label managerHeader = new Label("~ MANAGERS ~");
		
		Label teamHeader = new Label("~ TEAMS ~");
		
		//ADD PLAYER TEXTFIELDS
		
			//PLAYER FIRSTNAME
			TextField playerFirstName = new TextField();
			playerFirstName.setPromptText("First Name");
			
			//PLAYER MIDDLENAME
			TextField playerMiddleName = new TextField();
			playerMiddleName.setPromptText("Middle Name");
			
			//PLAYER LASTNAME
			TextField playerLastName = new TextField();
			playerLastName.setPromptText("Last Name");
			
			//GOALS
			TextField goalsEnter = new TextField();
			goalsEnter.setPromptText("Goals Scored/Saved");
			
			//GOALIE
			TextField goalieEnter = new TextField();
			goalieEnter.setPromptText("Is Goalie? (true/false)");
		
			
		//ADD MANAGER TEXTFIELDS
			
			//MANAGER FIRSTNAME
			TextField managerFirstName = new TextField();
			managerFirstName.setPromptText("First Name");
			
			//MANAGER MIDDLENAME
			TextField managerMiddleName = new TextField();
			managerMiddleName.setPromptText("Middle Name");
			
			//MANAGER LASTNAME
			TextField managerLastName = new TextField();
			managerLastName.setPromptText("Last Name");
			
			//DATEOFBIRTH
			TextField dobEnter = new TextField();
			dobEnter.setPromptText("Date of Birth (DD-MM-YY)");
			
			//STARRATING
			TextField starEnter = new TextField();
			starEnter.setPromptText("Star Rating");
		
			
		//ADD TEAM TEXTFIELDS
			
			//TEAMNAME
			TextField teamEnter = new TextField();
			teamEnter.setPromptText("Team Name");
			
			//TEAMCOLOUR
			TextField teamColour = new TextField();
			teamColour.setPromptText("Team Colour");
			
			//TEAMPLAYER
			TextField teamPlayer = new TextField();
			teamPlayer.setPromptText("Player Name (TEAM NAME ABOVE MUST BE ENTERED)");
			teamPlayer.setPrefWidth(325);
			
			//TEAMMANAGER
			TextField teamManager = new TextField();
			teamManager.setPromptText("Manager Name (TEAM NAME ABOVE MUST BE ENTERED)");
			teamManager.setPrefWidth(325);
		
			
		//HOME SCENE
		
			/**
			 * Create buttons and actions necessary for home (primaryStage) scene of program
			 * Also creating HBoxes, VBoxes, and BorderPanes to neatly present all of these buttons on the homepage
			 */
			
			add = new Button("Add Player/Manager/Team");
			add.setOnAction(e -> window.setScene(addScene));
			
			remove = new Button("Remove Player/Manager/Team");
			remove.setOnAction(e -> window.setScene(removeScene));
			
			edit = new Button("Edit Player");
			edit.setOnAction(e -> window.setScene(editScene));
			
			listTeams = new Button ("List Teams");
			
			listManagers = new Button ("List Managers");
			
			listTeamPlayers = new Button ("List Players");
			
			TextField teamEntry = new TextField();
			teamEntry.setPromptText("Players from Which Team?");
			teamEntry.setPrefWidth(160);
			
			exit = new Button("Exit");
			exit.setOnAction(e -> Platform.exit());
			
			TextArea entries = new TextArea();
			entries.setPrefHeight(50);
			entries.setPrefWidth(50);
			
			HBox listTeamPlayersBox = new HBox();
			
			listTeamPlayersBox.getChildren().addAll(listTeamPlayers, teamEntry);
			
			VBox homeButtons = new VBox();
			homeButtons.setSpacing(10);
			
			homeButtons.getChildren().addAll(add, remove, edit, listTeams, listManagers);
			
			BorderPane amal = new BorderPane();
			
			amal.setTop(homeButtons);
			BorderPane.setMargin(homeButtons, new Insets(20));
			
			amal.setCenter(entries);
			BorderPane.setMargin(entries, new Insets(100, 0, 0, -250));
			
			amal.setLeft(listTeamPlayersBox);
			BorderPane.setMargin(listTeamPlayersBox, new Insets(20, 0, 0, 20));
			
			amal.setBottom(exit);
			BorderPane.setMargin(exit, new Insets(20));
			
		    homeScene = new Scene(amal, 800, 600); 
		
		//ADD SCENE

			//ADD PLAYER ROWS
			
				addPlayer = new Button("Add Player");
				
				addPlayer.setOnAction(e -> controller.dbquery.insertPlayer(con, null, new model.Player(playerFirstName.getText(), playerMiddleName.getText(), playerLastName.getText(), "", "", Integer.parseInt(goalsEnter.getText()), Boolean.parseBoolean(goalieEnter.getText()))));
				
				GridPane players = new GridPane();
				
				players.addRow(0, playerHeader);
				players.addRow(1, playerFirstName, playerMiddleName, playerLastName, goalsEnter, goalieEnter);
				players.addRow(2, addPlayer);
		
				players.setVgap(10);
				players.setHgap(5);
				
			//ADD MANAGER ROWS
			
				addManager = new Button ("Add Manager");
				
				addManager.setOnAction(e -> controller.dbquery.insertManager(con, null, new model.Manager(managerFirstName.getText(), managerMiddleName.getText(), managerLastName.getText(), "", "", dobEnter.getText(), Integer.parseInt(starEnter.getText()))));
				
				GridPane managers = new GridPane();
				
				managers.addRow(0, managerHeader);
				managers.addRow(1, managerFirstName, managerMiddleName, managerLastName, dobEnter, starEnter);
				managers.addRow(2, addManager);
				
				managers.setVgap(10);
				managers.setHgap(5);
				
			//ADD TEAM ROWS
			
				addTeam = new Button ("Add Team");
				addTeam.setOnAction(e -> controller.dbquery.insertTeam(con, new model.Team(teamEnter.getText(), teamColour.getText())));
				
				addTeamPlayer = new Button ("Add Player to Team");
				addTeamPlayer.setOnAction(e -> controller.dbquery.addTeamPlayer(con, teamPlayer.getText(), teamEnter.getText()));
				
				addTeamManager = new Button ("Add Manager to Team");
				addTeamManager.setOnAction(e -> controller.dbquery.addTeamManager(con, teamManager.getText(), teamEnter.getText()));
				
				GridPane teams = new GridPane();
				
				teams.addRow(0, teamHeader);
				teams.addRow(1, teamEnter, teamColour);
				teams.addRow(2, addTeam);
				teams.addRow(3, teamPlayer);
				teams.addRow(4, addTeamPlayer);
				teams.addRow(5, teamManager);
				teams.addRow(6, addTeamManager);
				
				teams.setVgap(10);
				teams.setHgap(5);
			
			//ADD HOME BUTTON
				
				GridPane homePane = new GridPane();
				
				home = new Button("Home");
				
				homePane.addRow(0, home);
				
				home.setOnAction(e -> window.setScene(homeScene));
				
			//ADD ALL FUNCTIONS INTO BORDERPANE
				
				BorderPane addScenePane = new BorderPane();
				
				addScenePane.setTop(players);
				BorderPane.setMargin(players, new Insets(20));
				
				addScenePane.setCenter(managers);
				BorderPane.setMargin(managers, new Insets(20, 0, -200, -500));
				
				addScenePane.setLeft(teams);
				BorderPane.setMargin(teams,  new Insets(150, 20, 0, 20));
				
				addScenePane.setBottom(homePane);
				BorderPane.setMargin(homePane, new Insets(20));
				
				addScene = new Scene(addScenePane, 800, 600);
			
		//REMOVE SCENE
		
			removeHome = new Button("Home");
			removeHome.setOnAction(e -> window.setScene(homeScene));
			
			//REMOVE PLAYER
			
				removePlayer = new Button("Remove Player");
				
				TextField removePlayerFirstName = new TextField();
				removePlayerFirstName.setPromptText("First Name of Player");
				
				TextField removePlayerLastName = new TextField();
				removePlayerLastName.setPromptText("Last Name of Player");
				
				removePlayer.setOnAction(e -> controller.dbquery.removePlayer(con, removePlayerFirstName.getText(), removePlayerLastName.getText()));
			
			//REMOVE MANAGER
				
				removeManager = new Button("Remove Manager");
				
				TextField removeManagerFirstName = new TextField();
				removeManagerFirstName.setPromptText("First Name of Manager");
			
				TextField removeManagerLastName = new TextField();
				removeManagerLastName.setPromptText("Last Name of Manager");
			
				removeManager.setOnAction(e -> controller.dbquery.removePlayer(con, removeManagerFirstName.getText(), removeManagerLastName.getText()));
				
			//REMOVE TEAM
				
				removeTeam = new Button("Remove Team");
				
				TextField removeTeamName = new TextField();
				removeTeamName.setPromptText("Team to Remove");
				
				removeTeam.setOnAction(e -> controller.dbquery.removeTeam(con, removeTeamName.getText()));
			
				
			GridPane remove = new GridPane();
			
			remove.addRow(0, removePlayerFirstName, removePlayerLastName, removePlayer);
			remove.addRow(1, removeManagerFirstName, removeManagerLastName, removeManager);
			remove.addRow(2, removeTeamName, removeTeam);
			
			remove.setVgap(10);
			remove.setHgap(5);
			
			BorderPane removeScenePane = new BorderPane();
			
			removeScenePane.setTop(remove);
			BorderPane.setMargin(remove, new Insets(20));
			
			removeScenePane.setBottom(removeHome);
			BorderPane.setMargin(removeHome, new Insets(20));
			
			removeScene = new Scene(removeScenePane, 800, 600);
		
			
		//EDIT SCENE
			
			//EDIT PLAYER
			
				editHome = new Button("Home");
				editHome.setOnAction(e -> window.setScene(homeScene));
				
				TextField editPlayerFirstName = new TextField();
				editPlayerFirstName.setPromptText("Player Firstname");
				
				TextField editPlayerLastName = new TextField();
				editPlayerLastName.setPromptText("Player Lastname");
				
				TextField newGoals = new TextField();
				newGoals.setPromptText("New Goal Amount");
				
				editPlayer = new Button("Update Player");
				editPlayer.setOnAction(e -> controller.dbquery.editPlayer(con, editPlayerFirstName.getText(), editPlayerLastName.getText(), newGoals.getText()));
				
				
			GridPane editPlayerGrid = new GridPane();
			
			editPlayerGrid.addRow(0, editPlayerFirstName, editPlayerLastName);
			editPlayerGrid.addRow(1, newGoals);
			editPlayerGrid.addRow(2, editPlayer);
			
			editPlayerGrid.setHgap(5);
			editPlayerGrid.setVgap(10);
			
			BorderPane editScenePane = new BorderPane();
			
			editScenePane.setTop(editPlayerGrid);
			BorderPane.setMargin(editPlayerGrid, new Insets(20));
			
			editScenePane.setBottom(editHome);
			BorderPane.setMargin(editHome, new Insets(20));
			
			editScene = new Scene(editScenePane, 800, 600);
			
			
		//LIST TEAMS IN A LEAGUE
			
			listTeams.setOnAction(e -> entries.setText(controller.dbquery.listManagers(con)));
			
		//LIST MANAGERS
			
			listManagers.setOnAction(e -> entries.setText(controller.dbquery.listManagers(con)));
			
		//LIST PLAYERS ON TEAM
			
			listTeamPlayers.setOnAction(e -> entries.setText(controller.dbquery.listTeamPlayers(con, teamEntry.getText())));
			
	    //ICON
			
			Image image = new Image("file:sans.png");

	    //SET PRIMARY STAGE
	    
		    primaryStage.setScene(homeScene);
		    primaryStage.setResizable(false);
		    primaryStage.setTitle("R00178736 - Assignment 2 (Part 2)");
		    primaryStage.getIcons().add(image);
		    primaryStage.show();  
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}
