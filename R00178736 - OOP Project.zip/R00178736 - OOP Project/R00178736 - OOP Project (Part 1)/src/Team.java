// Name: Keith Bullman
// ID: R00178736
// Class: SDH2-A

import java.util.ArrayList;

public class Team {

	private ArrayList<Manager> manager;
	private ArrayList<Player> players;
	private int playerCount;
	private String colour;
	private String name;
	
	public Team(String name, String colour) {
		this.manager = new ArrayList<Manager>();
		this.players = new ArrayList<Player>();
		this.playerCount = 0;
		this.name = name;
		this.colour = colour;
	}
	
	public Name getManager() {
		return this.manager.get(0).getName();
	}
	
	public String getPlayers() {
		String result = "";
		for(int counter=  0; counter < this.players.size(); counter++) {
			result += this.players.get(counter) + "\n";
		}
		return result;
	}
	
	public int getPlayerCount() {
		return this.playerCount;
	}
	
	public String getColour() {
		return this.colour;
	}
	
	public String getName() {
		return this.name;
	}
	
	public void addManager(Manager m) {
		this.manager.add(m);
	}
	
	public void getPlayer() {
		for(int counter = 0; counter < players.size(); counter++) {
			players.get(counter);
		}
	}
	
	public void removeManager(int pointer) {
		manager.remove(pointer);
	}
	
	public void addPlayer(Player newPlayer) {
		this.players.add(newPlayer);
		this.playerCount += 1;
	}
	
	public void removePlayer(Player pickedPlayer) {
		this.players.remove(pickedPlayer);
		this.playerCount -= 1;
	}
	
	public String toString() {
		return this.getName() + ", Colour: " + this.getColour();
	}
}
