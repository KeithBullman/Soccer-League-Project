// Name: Keith Bullman
// ID: R00178736
// Class: SDH2-A

public class Manager extends Person{

	private String dob;
	private int star;
	
	public Manager(String first, String middle, String last, String ph, String em, String dob, int star) {
		
		super(first, middle, last, ph, em);
		this.dob = dob;
		this.star = star;
		
	}
	
	public String getDOB() {
		return this.dob;
	}
	
	public void setDOB(String dob) {
		this.dob = dob;
	}
	
	public int getStar() {
		return this.star;
	}
	
	public void setStar(int star) {
		this.star = star;
	}
	
	public String toString() {
		return this.getName() + "has a date of birth of " + this.getDOB() + " and has a Star Rating: " + this.getStar();
	}
}
