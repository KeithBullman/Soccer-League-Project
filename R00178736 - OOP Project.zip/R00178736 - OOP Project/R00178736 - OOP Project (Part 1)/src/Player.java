// Name: Keith Bullman
// ID: R00178736
// Class: SDH2-A

public class Player extends Person{

	private int numGoals;
	private boolean goalie;
	
	public Player(String first, String middle, String last, String ph, String em, int goals, boolean goalie) {
		
		super(first, middle, last, ph, em);
		this.numGoals = goals;
		this.goalie = goalie;
		
	}
	
	public int getGoals() {
		return this.numGoals;
	}
	
	public void setGoals(int goals) {
		this.numGoals = goals;
	}
	
	public boolean getGoalie() {
		return this.goalie;
	}
	
	public void setGoalie(boolean goalie) {
		this.goalie = goalie;
	}
	
	public String toString() {
		
		if(goalie == false) {
			return this.getName() + " - NOT A GOALIE - SCORED " + this.getGoals() + " GOALS";
		}
		
		else {
			return this.getName() + " - GOALIE - BLOCKED " + this.getGoals() + " SHOTS";
		}
	}
}
