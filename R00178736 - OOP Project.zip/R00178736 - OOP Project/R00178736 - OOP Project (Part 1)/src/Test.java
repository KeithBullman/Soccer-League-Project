// Name: Keith Bullman
// ID: R00178736
// Class: SDH2-A

import java.io.*;

public class Test {

	public static void main(String[] args) throws IOException {
		//==================================BEGINNING OF TEST===================================
		
		//PLAYER
		Player p1test = new Player("Keith", "Edward", "Bullman", "12345", "keith.bullman", 10, false);
		Player p2test = new Player("Daniel", "Givee", "Twome", "31542", "daniel.twome", 5, true);
		Player p3test = new Player("Adam", "", "Murphy", "67890", "adam.murphy", 4, false);
		Player p4test = new Player("James", "Shocks", "O' Shaughnessy", "63811", "james.shock", 3, true);
		
		// PLAYER 1 FUNCTIONS TEST
		System.out.println("Name: " + p1test.getName());
		System.out.println("Phone: " + p1test.getPhone());
		System.out.println("Email: " + p1test.getEmail());
		System.out.println("Is Goalie? :" + p1test.getGoalie());
		if (p1test.getGoalie() == true) {
			System.out.println("Saves: " + p1test.getGoals());
		} else {
			System.out.println("Goals: " + p1test.getGoals());
		}
		System.out.println();

		//MANAGER
		Manager m1test = new Manager("John", "", "Lewis", "54321", "john.lewis", "01-01-1900", 5);
		Manager m2test = new Manager("Steven", "Reilly", "Donoghue", "01842", "steven.dono", "01-02-0003", 3);
		
		// MANAGER 1 FUNCTIONS TEST
		System.out.println("Name: " + m1test.getName());
		System.out.println("Phone: " + m1test.getPhone());
		System.out.println("Email: " + m1test.getEmail());
		System.out.println("Date of Birth: " + m1test.getDOB());
		System.out.println("Star Rating: " + m1test.getStar());
		System.out.println();

		//TEAM
		Team t1test = new Team("Cork", "Red");
		Team t2test = new Team("Limerick", "Green");
		t1test.addManager(m1test);
		t1test.addPlayer(p1test);
		
		// TEAM 1 FUNCTIONS TEST
		System.out.println("Team Name: " + t1test.getName());
		System.out.println("Team Colour: " + t1test.getColour());
		System.out.println("Team Manager: " + t1test.getManager());
		System.out.println("Team Players: " + t1test.getPlayers());
		System.out.println("Amount of Players on Team: " + t1test.getPlayerCount());
		System.out.println();

		//LEAGUE
		League l1 = new League("Cork Finals");
		l1.addTeam(t1test);
		l1.addTeam(t2test);
		
		// LEAGUE 1 FUNCTIONS TEST
		System.out.println("League Name: " + l1.getName());
		System.out.println("Teams: " + l1.getTeams());
		System.out.println();
		
		//=====================================END OF TEST======================================
	}
}